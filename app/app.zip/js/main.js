$(function(){
	$('.allTask').bxSlider({
		controls: false
	});
})